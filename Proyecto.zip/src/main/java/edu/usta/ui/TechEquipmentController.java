package edu.usta.ui;

import edu.usta.domain.entities.Provider;
import edu.usta.domain.entities.TechEquipment;
import edu.usta.domain.enums.EquipmentStatus;
import edu.usta.domain.enums.EquipmentType;
import edu.usta.domain.repositories.JDBCTechEquipmentRepository;
import edu.usta.domain.repositories.JDBCProviderRepository;
import edu.usta.infrastructure.db.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class TechEquipmentController implements Initializable {

    @FXML
    private TextField serialField;
    @FXML
    private TextField brandField;
    @FXML
    private TextField modelField;
    @FXML
    private ComboBox<EquipmentType> typeBox;
    @FXML
    private ComboBox<EquipmentStatus> stateBox;
    @FXML
    private ComboBox<Provider> providerBox;
    @FXML
    private TextField osField;
    @FXML
    private TextField ramField;
    @FXML
    private TextField imageField;

    private JDBCTechEquipmentRepository techRepo;
    private JDBCProviderRepository providerRepo;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        DatabaseConnection db = DatabaseConnection.getInstance();

        techRepo = new JDBCTechEquipmentRepository(db);
        providerRepo = new JDBCProviderRepository(db);

        typeBox.getItems().addAll(EquipmentType.values());
        stateBox.getItems().addAll(EquipmentStatus.values());

        List<Provider> providers = providerRepo.findAll();
        providerBox.getItems().addAll(providers);
    }

    @FXML
    public void saveTech(ActionEvent event) {

        TechEquipment tech = new TechEquipment(
                serialField.getText(),
                brandField.getText(),
                modelField.getText(),
                typeBox.getValue(),
                stateBox.getValue(),
                providerBox.getValue(),
                imageField.getText(),
                osField.getText(),
                Integer.parseInt(ramField.getText()));

        techRepo.create(tech);
        System.out.println("✔ Equipo Tecnológico guardado en la BD");

        clearFields();
    }

    @FXML
    public void cancel(ActionEvent event) {
        clearFields();
    }

    private void clearFields() {
        serialField.clear();
        brandField.clear();
        modelField.clear();
        osField.clear();
        ramField.clear();
        imageField.clear();

        typeBox.setValue(null);
        stateBox.setValue(null);
        providerBox.setValue(null);
    }
}
