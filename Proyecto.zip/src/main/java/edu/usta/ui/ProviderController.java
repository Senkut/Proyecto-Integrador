package edu.usta.ui;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;

public class ProviderController {

    @FXML
    private TextField nameField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField phoneField;
    @FXML
    private TextField addressField;

    @FXML
    public void saveProvider(ActionEvent event) {
        System.out.println("Guardando Proveedor...");
        System.out.println(nameField.getText());
        System.out.println(emailField.getText());
        System.out.println(phoneField.getText());
        System.out.println(addressField.getText());

        // Aquí luego agregamos el INSERT a la BD
    }

    @FXML
    public void clearForm(ActionEvent event) {
        nameField.clear();
        emailField.clear();
        phoneField.clear();
        addressField.clear();
    }

    @FXML
    private void goBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/MainView.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}